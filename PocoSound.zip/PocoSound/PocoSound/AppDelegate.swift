//
//  AppDelegate.swift
//  PocoSound
//
//  Created by 駒木剛瑠 on 2021/02/13.
//

import UIKit
import AVFoundation


let mainBoundSize = UIScreen.main.bounds
var renewFlag = true
//データ格納変数-----------------------------
var titleSoundArr:[String] = [] {
    didSet{
        //NotificationCenter.default.post(name: NSNotification.Name("reload"), object: nil)
        collectionView.reloadData()
    }
}



let collectionView: UICollectionView = {
    let screenSize: CGSize = CGSize(width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    layout.scrollDirection = .vertical
    layout.minimumInteritemSpacing = 5 //横間隔
    layout.minimumLineSpacing = 20 //縦間隔
    let collectionView = UICollectionView( frame: CGRect(x: 20, y: 80, width: screenSize.width-40, height: screenSize.height/1.8 ), collectionViewLayout: layout)
    collectionView.backgroundColor = .systemGroupedBackground
    collectionView.register(CollectionViewCell.self, forCellWithReuseIdentifier: "CollectionViewCell")
    return collectionView
}()

//-------------------------------------



@main
class AppDelegate: UIResponder, UIApplicationDelegate {



    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        
        sleep(UInt32(1.5))
        
        
        return true
        
        
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}


