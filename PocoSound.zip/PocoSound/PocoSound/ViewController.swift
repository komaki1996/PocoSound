//
//  ViewController.swift
//  PocoSound
//
//  Created by 駒木剛瑠 on 2021/02/13.
//

import UIKit
import AVFoundation
import MediaPlayer
import KYShutterButton
import SCLAlertView
import YoutubePlayer_in_WKWebView


class ViewController: UIViewController, AVAudioRecorderDelegate, AVAudioPlayerDelegate, UIGestureRecognizerDelegate, UITextFieldDelegate, UIViewControllerTransitioningDelegate, MPMediaPickerControllerDelegate, WKYTPlayerViewDelegate  {
    
    //関数系変数はAppDelegate
    //collectionViewはAppDelegateでグローバル変数として定義(他Viewから更新したいため)
    //関数用変数-----------------------------
    let userDefaults = UserDefaults.standard
    var audioPlayer: AVAudioPlayer! //音
    var audioRecorder: AVAudioRecorder!
    var musicPlayer = MPMusicPlayerController.applicationMusicPlayer
    let youtubePlayer = WKYTPlayerView()
    var isState:Bool = false
    //-------------------------------------
    
    //View-------------------------
    let insertForm = UITextField()
    //---------------------------------


    override func viewDidLoad() {
        super.viewDidLoad()
        self.Initialize()

    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if renewFlag {
            self.loadView()
            self.viewDidLoad()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    //ボタン押した時の動作
    @objc func PressSoundBtn(_ sender: CustomButton) {
        PlaySounds(Sound: (sender.titleLabel?.text)!)
    }
    //
    @objc func DeleteBtn(_ gesture: UITapGestureRecognizer) {
        print("")
    }

    @objc func PressStopBtn(sender: CustomButton) {
        if audioPlayer.self != nil {
            audioPlayer.stop()
        }
    }
    
    @objc func OpenRecordMenu(_ sender: CustomButton) {
        presentPanModal(OpenRecordView())
        //presentPanModal(WebViewController())
    }

    @objc func singleTap(_ gesture: UITapGestureRecognizer) {
        
        if isState == true {
            if audioPlayer.self != nil {
                audioPlayer.stop()
            }
            youtubePlayer.pauseVideo()
            isState.toggle()
        } else {
            youtubePlayer.playVideo()
            isState.toggle()
        }

    }
    
    // サウンド再生
    func PlaySounds(Sound: String) {
        let audioUrl = getURL().appendingPathComponent("\(Sound).m4a")
        do {
            youtubePlayer.pauseVideo()
            audioPlayer = try AVAudioPlayer(contentsOf: audioUrl)
            audioPlayer.play()
        } catch {
            // error handling
            print(error.localizedDescription)
            print("AVAudioPlayer init failed")
            SCLAlertView().showNotice("エラー", subTitle: "音声の再生に失敗しました。再度録音を試してください。問題が解決しない場合は、開発者に問い合わせお願いします。(E001)")
        }
    }

    // WKYTPlayerViewDelegate - データのロード完了後のDelegateメソッド
    func playerViewDidBecomeReady(_ playerView: WKYTPlayerView) {
        playerView.playVideo()
    }
    
    func Initialize() {
        
        self.view.backgroundColor = .systemGroupedBackground
        
        //UserDefaultから配列データをロード
        if let tempArr = UserDefaults.standard.stringArray(forKey: "title") {
            titleSoundArr = tempArr
        }

        PocoSound.collectionView.dataSource = self
        PocoSound.collectionView.delegate = self
        self.view.addSubview(PocoSound.collectionView)

        var playlist = ""
        if let playlistId = userDefaults.string(forKey: "PlayListID") {
            playlist = playlistId
            let result = playlist.range(of: "?list=")
            if let theRange = result {
                playlist = String(playlist[theRange.upperBound...])
            }
            
    
        } else {
            DispatchQueue.main.async {
                SCLAlertView().showInfo("PlayList未設定", subTitle: "PlayListが未設定のようです。プレイリスト設定画面で設定してください。")
            }
            
        }
        
        youtubePlayer.frame = CGRect(x:0, y: PocoSound.collectionView.frame.maxY, width:mainBoundSize.width, height: mainBoundSize.height-PocoSound.collectionView.frame.maxY)
        //youtubePlayer.frame = contentView.frame
        self.view.addSubview(youtubePlayer)
        youtubePlayer.delegate = self
        youtubePlayer.load(withVideoId: "QnrIZBHNH7E",
                        playerVars: ["playsinline":1, // 全画面ではなくViewの範囲内で再生。
                                     "autoplay":1,
                                     "listType":"playlist",
                                     "list":playlist
                        ])
        renewFlag.toggle() //Youtube読み込み完了=false
        
        let OpenRecordMenuBtn = CustomButton(frame: CGRect(x:mainBoundSize.width-55, y: mainBoundSize.height-110, width: 50, height: 30))
        OpenRecordMenuBtn.layer.cornerRadius = 5
        OpenRecordMenuBtn.layer.opacity = 0.8
        OpenRecordMenuBtn.backgroundColor = .startColor
        OpenRecordMenuBtn.setImage(UIImage(systemName: "gearshape")?.resized(toWidth: 30)?.withTintColor(.white), for: .normal)
        OpenRecordMenuBtn.addTarget(self, action: #selector(OpenRecordMenu), for: .touchUpInside)
        self.view.addSubview(OpenRecordMenuBtn)
        
        //let moviePlayBtn = CustomButton(frame: CGRect(x:15, y: mainBoundSize.height-140, width: 50, height: 50))
        let moviePlayBtn = CustomButton(frame: CGRect(x:15, y: mainBoundSize.height-110, width: 50, height: 30))
        moviePlayBtn.layer.cornerRadius = 5
        moviePlayBtn.backgroundColor = .startColor
        moviePlayBtn.setImage(UIImage(systemName:"play.fill")?.resized(toWidth:30)?.withTintColor(.white), for: .normal)
        moviePlayBtn.addTarget(self, action: #selector(singleTap), for: .touchUpInside)
        //self.view.addSubview(moviePlayBtn)
        
    }
}


extension ViewController:UICollectionViewDataSource {
    //cellの個数設定
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return titleSoundArr.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        
        //Viewの重複防ぐため削除
        for subview in cell.subviews{
              subview.removeFromSuperview()
        }

        DispatchQueue.main.async {
            let PlayBtn = CustomButton()
                PlayBtn.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
                PlayBtn.addTarget(self, action: #selector(self.PressSoundBtn(_:)), for: .touchUpInside)
                PlayBtn.backgroundColor = UIColor(displayP3Red: 79/255, green: 172/255, blue: 254/255,alpha: 1.0)
                PlayBtn.setTitleColor(.white, for: .normal)
                PlayBtn.setTitle(titleSoundArr[indexPath.row], for: .normal)
            
            //事前に削除用のViewをPlayBtnの上に載せておく（非表示）
            let deleteview = UIView()
                deleteview.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
                deleteview.tag = 999 //999で判断
                deleteview.backgroundColor = .darkGray
                deleteview.alpha = 0.4
                deleteview.clipsToBounds = true
                deleteview.isHidden = true
            
            
            let delimg = UIImageView(frame: CGRect(x: 0, y: 0, width: 80, height: 80))
                delimg.image = UIImage(systemName: "trash.slash")?.withTintColor(.blue)
                delimg.center = deleteview.center
                
            deleteview.addSubview(delimg)
            PlayBtn.addSubview(deleteview)
            cell.addSubview(PlayBtn)
        }
 

        return cell
        
            
    }
    
}

//イベントの設定(何もなければ記述の必要なし)
extension ViewController: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    //表示時のデザイン
    
     func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        cell.alpha = 0
        UIView.animate(withDuration: 0.3, delay: 0.25, options: .allowUserInteraction, animations: {
            cell.alpha = 1
        }, completion: nil)
    }
 
  
    //cellのサイズの設定
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: 100)
    }
}
