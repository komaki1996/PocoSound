//
//  OpenRecordView.swift
//  PocoSound
//
//  Created by 駒木剛瑠 on 2021/02/26.
//

//
//  BudgetViewController.swift
//  FoodPicker
//
//  Created by 駒木剛瑠 on 2020/05/24.
//  Copyright © 2020 駒木剛瑠. All rights reserved.
//

import UIKit
import KYShutterButton
import PanModal
import AVFoundation
import SCLAlertView

class OpenRecordView: UIViewController, AVAudioRecorderDelegate, UITextFieldDelegate  {
    
    //関数用変数-----------------------------
    let userDefaults = UserDefaults.standard
    var audioPlayer: AVAudioPlayer! //音
    var audioRecorder: AVAudioRecorder!
    //-------------------------------------
    
    
    //View-----------------------------
    let ContentView = UIView()
    let textBox = UITextField()
    //---------------------------------
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Inittialize()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)

    }
    func Inittialize() {
        
        //ContentView
        ContentView.frame = mainBoundSize
        ContentView.backgroundColor = .white
        self.view.addSubview(ContentView)
        
        //編集モードボタン
        let editBtn = CustomButton()
        editBtn.frame = CGRect(x: 3, y: 3, width: mainBoundSize.width/3, height: 40)
        editBtn.setTitle("編集モード", for: .normal)
        editBtn.setTitleColor(.white, for: .normal)
        editBtn.addTarget(self, action: #selector(EditMode), for: .touchUpInside)
        editBtn.backgroundColor = .startColor
        editBtn.layer.shadowColor = UIColor.startColor.cgColor
        editBtn.layer.shadowOffset = CGSize(width: 0, height: 3)
        editBtn.layer.cornerRadius = 5
        editBtn.layer.shadowOpacity = 0.5
        editBtn.layer.shadowRadius = 10

        ContentView.addSubview(editBtn)
        
        
        
        //色変更ボタン
        let SetPlaylistIdBtn = CustomButton()
        SetPlaylistIdBtn.frame = CGRect(x: mainBoundSize.width-(mainBoundSize.width/3+3), y: 3, width: mainBoundSize.width/3, height: 40)
        SetPlaylistIdBtn.setTitle("PlayList設定", for: .normal)
        SetPlaylistIdBtn.setTitleColor(.white, for: .normal)
        SetPlaylistIdBtn.addTarget(self, action: #selector(OpenSetPlayList), for: .touchUpInside)
        SetPlaylistIdBtn.backgroundColor = .startColor
        SetPlaylistIdBtn.tag = 0
        SetPlaylistIdBtn.layer.shadowColor = UIColor.startColor.cgColor
        SetPlaylistIdBtn.layer.shadowOffset = CGSize(width: 0, height: 3)
        SetPlaylistIdBtn.layer.cornerRadius = 5
        SetPlaylistIdBtn.layer.shadowOpacity = 0.5
        SetPlaylistIdBtn.layer.shadowRadius = 10

        ContentView.addSubview(SetPlaylistIdBtn)
        
        
        
    
        //RecodeBtn
        let recordBtn = KYShutterButton(frame: CGRect(x: mainBoundSize.width/2-50, y: mainBoundSize.width-150, width: 100, height: 100),shutterType: .normal,buttonColor: .red)
        recordBtn.addTarget(self, action: #selector(PressRecodeBtn), for: .touchUpInside)
        recordBtn.arcColor = .gray
        //recordBtn.progressColor = .yellow
        ContentView.addSubview(recordBtn)
        
        //TextField
        textBox.frame.size = CGSize(width: mainBoundSize.width/1.5, height: 60)
        textBox.frame.origin = CGPoint(x: (mainBoundSize.width-textBox.frame.width)/2, y: recordBtn.frame.minY-120)
        textBox.backgroundColor = .systemGray5
        textBox.layer.cornerRadius = 8
        textBox.delegate = self
        textBox.placeholder = "ボタンのタイトルを入力"
        textBox.textColor = .darkGray
        ContentView.addSubview(textBox)

    }


    //編集ボタン押した時の動作
    @objc func EditMode(sender: CustomButton) {
        ApperDeleteBtn()
    }
    
    //編集ボタン押した時の動作
    
    @objc func OpenSetPlayList(sender: CustomButton) {
        let alert = SCLAlertView()
        let listId = alert.addTextField("PL....")
        var currentId = ""
        if let temp = self.userDefaults.string(forKey: "PlayListID") {
            currentId = temp
        }
        alert.addButton("設定"){
            if listId.text != "" {
                self.userDefaults.set(listId.text, forKey: "PlayListID")
            }
        }
        alert.showEdit("Youtubeプレイリスト設定", subTitle: "YoutubeのPlayListを作成しPlayListIDをセットしてください。\n\n\(currentId)", closeButtonTitle: "閉じる")


    }
    
    
    //録音ボタン押した時の動作
    @objc func PressRecodeBtn(sender: KYShutterButton) {

        if textBox.text == "" {
            SCLAlertView().showWait("タイトル未入力", subTitle: "ボタンのタイトル \nを入力してください。")
        } else if titleSoundArr.contains(textBox.text!) {
            SCLAlertView().showWait("同一タイトル名", subTitle: "同じボタンのタイトル名が既に存在します。違うタイトルを設定してください。")
        }else {
            
            switch sender.buttonState {
            case .normal:
                sender.buttonState = .recording
                RecodeSounds()
                //setupAudioRecorder(sound: textBox.text!)
            case .recording:
                sender.buttonState = .normal
                //titleSoundArr配列に変化があれば、collectioView更新
                titleSoundArr = UserDefaults.standard.stringArray(forKey: "title")!
            }
            
        }
    }
    
    
    
    
    
    
    // 録音
    func RecodeSounds() {
        let session = AVAudioSession.sharedInstance()
        try! session.setCategory(AVAudioSession.Category.playAndRecord,mode: .default, options: .defaultToSpeaker)
        try! session.setActive(true)
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 44100, //44100
            AVNumberOfChannelsKey: 2, //2
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        
        let audioUrl = getURL().appendingPathComponent("\(textBox.text ?? "").m4a")
       
        audioRecorder = try! AVAudioRecorder(url: audioUrl, settings: settings)
        audioRecorder.delegate = self
        audioRecorder.record()
        saveSoundData(title: textBox.text!)

        
    }

    //UserDefaultへデータ配列追加
    func saveSoundData(title:String) {
        var titleArr:[String] = [title]
        if let tempArr:[String] = userDefaults.stringArray(forKey: "title") {
            //データが既にある場合は、既にある配列を上書きし、追加
            titleArr = tempArr
            titleArr.append(title)
        }
        userDefaults.set(titleArr, forKey: "title")   //データセット
    }

    
    
    
    
    //-----------------------------------------------------------------
    //改行でキーボード閉じる
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    //枠外タップでキーボードどじる
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    //-----------------------------------------------------------------
    

}


extension OpenRecordView: PanModalPresentable {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        //ステータスバーの色
        return .lightContent
    }
    
    var panScrollable: UIScrollView? {
        return nil
    }
    
    var longFormHeight: PanModalHeight {
        //メニューの高さ
        return .contentHeight(mainBoundSize.width)
    }
    
    var anchorModalToLongForm: Bool {
        return false
    }
}
