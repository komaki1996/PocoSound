//
//  WebViewController.swift
//  PocoSound
//
//  Created by 駒木剛瑠 on 2021/03/07.
//

import UIKit
import WebKit
import SCLAlertView
import PanModal
import YoutubePlayer_in_WKWebView

class WebViewController: UIViewController, WKNavigationDelegate, UIGestureRecognizerDelegate, WKYTPlayerViewDelegate {

    let mainbounds = UIScreen.main.bounds
    var webView: WKWebView!
    //private var progressView = UIProgressView(progressViewStyle: .bar)
    
    
    override func loadView() {
        super.loadView()
        // Viewを作成する
        let viewConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: viewConfiguration)
        self.view = webView
        webView.uiDelegate = self
        webView.navigationDelegate = self
        // リロードのイベントを受け取る
        self.webView.scrollView.bounces = true
        
        /*スワイプロード用
        let refreshControl = UIRefreshControl()
        self.webView.scrollView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshWebView(sender:)), for: .valueChanged)
 */
        
    }
    
    // Webページを読み込む
    override func viewDidLoad() {
        super.viewDidLoad()
        Initialize()
    }
    
    // ページをリロードするメソッド
    @objc func refreshWebView(sender: UIRefreshControl) {
       //webView.reload()
        sender.endRefreshing()
    }
    
    func Initialize() {
        //https://www.youtube.com/embed/gtjdzKYrn7s
        //https://www.youtube.com/embed/M7lc1UVf-VE?autoplay=1&origin=https://www.youtube.com/embed/NyUTYwZe_l4
        
       // let myURL = URL(string: "")
       // let myRequest = URLRequest(url: myURL!)
        // Webページを読み込む
        //webView.load(myRequest)
        
        
        let videoID = "QnrIZBHNH7E"
        let youtubePlayer = WKYTPlayerView(frame: CGRect(x: 0, y: 0, width:mainbounds.width, height: 300))
        self.view.addSubview(youtubePlayer)
        youtubePlayer.delegate = self
        youtubePlayer.load(withVideoId: videoID,
                        playerVars: ["playsinline":1//, // 全画面ではなくViewの範囲内で再生。
                                     //"playlist":["0SJHPnRY8YA"] // 最初の動画の後に自動再生されるプレイリスト。
                        ])
        
        
        
    }
    // WKYTPlayerViewDelegate - データのロード完了後のDelegateメソッド
    func playerViewDidBecomeReady(_ playerView: WKYTPlayerView) {
        playerView.playVideo()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - 読み込み開始
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        print("読み込み開始")
        

    }
    // MARK: - 読み込み完了
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("読み込み完了")
    }
    // MARK: - 読み込み失敗検知
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError: Error) {
        print("読み込み失敗検知")
        DispatchQueue.main.async {
            SCLAlertView().showError("ネットワークエラー", subTitle: "ネットワークが不安定です。再度接続を試みてください。")
        }
    }
    // MARK: - 読み込み失敗
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError: Error) {
        print("読み込み失敗")
    }
    
}

// target=”_blank”が設定されたリンク先を開けるようにする
extension WebViewController: WKUIDelegate {
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if navigationAction.targetFrame == nil {
            webView.load(navigationAction.request)
        }
        return nil
    }
}





extension WebViewController: PanModalPresentable {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        //ステータスバーの色
        return .lightContent
    }
    
    var panScrollable: UIScrollView? {
        return nil
    }
    
    var longFormHeight: PanModalHeight {
        //メニューの高さ
        return .contentHeight(mainBoundSize.height-100)
    }
    
    var anchorModalToLongForm: Bool {
        return false
    }
}
