//
//  CollectionViewCell.swift
//  PocoSound
//
//  Created by 駒木剛瑠 on 2021/02/21.
//

import UIKit


class CollectionViewCell: UICollectionViewCell {
    

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setup()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    func setup() {
        layer.borderColor = UIColor.white.cgColor
        self.clipsToBounds = true
        layer.borderWidth = 3.0
        layer.cornerRadius = 50
        //layer.shadowColor = UIColor.darkGray.cgColor
        //layer.shadowOffset = CGSize(width: 1, height: 1)
        //layer.shadowOpacity = 0.5
        
        
    }

    
}
    

