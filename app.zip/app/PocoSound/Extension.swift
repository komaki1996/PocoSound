//
//  Extension.swift
//  PocoSound
//
//  Created by 駒木剛瑠 on 2021/02/28.
//

import Foundation
import UIKit
import SCLAlertView


extension NSObject {
    
    //再生ボタンの上のデリートボタン表示/非表示
    func ApperDeleteBtn() {
        collectionView.layoutIfNeeded()
        let cell = collectionView.visibleCells
        if cell.count != 0 {
            for i in 0...(cell.count-1) {
                let subView = cell[i].subviews[0].subviews
                if subView.count > 1 {
                    if subView[2].tag == 999 {
                        if subView[2].isHidden == false {
                            subView[2].isHidden = true
                        } else {
                            subView[2].isHidden = false
                        }
                    }
                }
            }
        }
    }
    
    //ボタン削除
    func DeleteSoundData(title:String) {
        if let del_index = titleSoundArr.firstIndex(of: title) {
            titleSoundArr.remove(at: del_index)
            UserDefaults.standard.set(titleSoundArr, forKey: "title")   //データセット
        } else {
            SCLAlertView().showNotice("エラー", subTitle: "削除に失敗しました。開発者に問い合わせください。(E002)")
        }
    }
    
    //音声を保存しているディレクトリを返す（Documents）
    func getURL() -> URL{
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    
    
}

extension NSURL {
    
}

// --- resize Image for CategoryView ---
extension UIImage {
    func resized(toWidth size: CGFloat) -> UIImage? {
        let canvasSize = CGSize(width: size, height: size)
        UIGraphicsBeginImageContextWithOptions(canvasSize, false, scale)
        defer { UIGraphicsEndImageContext() }
        draw(in: CGRect(origin: .zero, size: canvasSize))
        return UIGraphicsGetImageFromCurrentImageContext()
    }
}


extension UIColor {
    static let startColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
    static let endColor = #colorLiteral(red: 0.2852321628, green: 0.938419044, blue: 0.9285692306, alpha: 1)
    
    static let customYellow = UIColor(red: 244/255, green: 219/255, blue: 113/255, alpha: 1.0)
    static let customPink = UIColor(red: 221/255, green: 107/255, blue: 182/255, alpha: 1.0)
    static let customBlue = UIColor(red: 109/255, green: 226/255, blue: 206/255, alpha: 1.0)
}


